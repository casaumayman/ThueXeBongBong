<div class="panel panel">
	<div class="panel-body">
		<div class="col-md-12" style=" text-align: center; font-weight: bold;">
			<a href="?thread=admin-ncp"><i class="fa fa-institution fa-3x"></i></a>
			<font face="Tahoma" size="5.9">THUÊ XE MÁY BÔNG BÔNG - GIAO DIỆN QUẢN LÝ</font>
		</div>

		<div class="col-md-3" style="margin-top: 20px">
			<button class="btn btn-success" onclick="window.location.href='?thread=admin-ncp'" style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080 " >Trang chủ admin</button>	
		</div>
		<div class="col-md-3" style="margin-top: 20px">
			<button class="btn btn-success" onclick="window.location.href='?thread=admin-manager'" style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080" >Quản lý admin</button>	
		</div>
		<div class="col-md-3" style="margin-top: 20px">
			<button class="btn btn-success" onclick="window.location.href='?thread=user-manager'" style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080" >Quản lý người dùng</button>	
		</div>
		<div class="col-md-3"  style="margin-top: 20px">
			<button class="btn btn-success" onclick="window.location.href='?thread=produc-manager'" style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080">Quản lý sản phẩm</button>	
		</div>
		<div class="col-md-3">
			<button class="btn btn-success" onclick="window.location.href='?thread=caterogies-manager'" style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080">Quản lý thể loại</button>	
		</div>
		<div class="col-md-3">
			<button class="btn btn-success" onclick="window.location.href='?thread=cart-manager'"style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080">Quản lý giỏ hàng</button>	
		</div>
		<div class="col-md-3">
			<button class="btn btn-success" onclick="window.location.href='?thread=feedback-manager'"style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080">Quản lý phản hồi</button>	
		</div>
		<div class="col-md-3">
			<button class="btn btn-success" onclick="window.location.href='?thread=xethue-manager'"style="width: 100%; margin-bottom: 5px; background-color: #800080;border-color: #800080">Quản lý xe đang thuê</button>	
		</div>
	</div>
</div>