
<div class="row" style="background-color: #000080;border-color:#F5DEB3; color: #ffff; margin-top: 20px" >
	<div class="col-md-4">
		<p style="font-weight: bold; padding-top: 20px; padding-left: 27px; ">  Nhóm thực hiện</p>
		<ol>
			<li><a href="https://www.facebook.com/hoapham266" target="_blank" style="color: #00FFFF"> Phạm Thị Hoa - 1611061509 </a></li>
			<li><a href="https://www.facebook.com/casaumayman" target="_blank" style="color: #00FFFF"> Huỳnh Huy Tuấn - 1611061776 </a></li>
			<li><a href="https://www.facebook.com/thuyvy.nguyen.1023611" target="_blank" style="color: #00FFFF"> Nguyễn Thuý Vy </a></li>
		</ol>
	</div>
	<div class="col-md-4" style="padding-top: 10px; font-weight: both; text-align: center;">
		<p> ĐỒ ÁN CÔNG NGHỆ PHẦN MỀM</p>
		<p> WEBSITE CỬA HÀNG CHO THUÊ XE MÁY ONLINE </p>
	</div>
		<div class="col-md-4" style=" padding-top: 20px;" >
		<p > <u><b> Địa Chỉ</b> </u>: 120 Lý Thường Kiệt, Phường Hải Thành,Tp Đồng Hới, Quảng Bình </p>
		<p><u><b>SĐT</b> </u> : 01654036388</p>
	</div>
</div>