<!-- begin-search -->
<div class="panel panel-primary">
	<div class="panel-heading">Tìm kiếm</div>
	<div class="panel-body">
		<form class="form-horizontal" action="?thread=tim-kiem" method="POST" style="margin-left: 10px; margin-right: 10px;">
			<div class="form-group">
				<input class="form-control" type="text" name="keyword" placeholder="Nhập từ khoá..." required>
			</div>
			<div class="form-group" style="text-align: center;">
				<button class="btn btn-primary" type="submit"><i class="fa fa-search" aria-hidden="true"></i> Tìm kiếm</button>
			</div>
		</form>
	</div>
</div>
	<!-- end-search -->
<div class="panel panel-green">
	<div class="panel-heading"><b>Fanpage</b></div>
	<div class="panel-body">
		<div class="fb-page" data-href="https://www.facebook.com/thuexemayhcm/" data-tabs="timeline" data-height="200" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/thuexemayhcm/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/thuexemayhcm/">Cho thuê xe máy thành phố Hồ Chí Minh</a></blockquote></div>
	</div>
</div>
<div class="panel panel">
	<div class="panel-heading"><b>Video về cửa hàng</b></div>
	<div class="panel-body">
		<iframe width="100%" height="200px" src="https://www.youtube.com/embed/bN-5-xGEis0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
</div>
<div class="panel panel">
	<div class="panel-heading"><b>Địa chỉ</b></div>
	<div class="panel-body">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.556979621453!2d106.61579481412203!3d17.480905804704136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314757288672b791%3A0xa2277d73879f6c66!2zMTIwIEzDvSBUaMaw4budbmcgS2nhu4d0LCBQaMaw4budbmcgSOG6o2kgVGjDoG5oLCDEkOG7k25nIEjhu5tpLCBRdeG6o25nIELDrG5oLCBWaWV0bmFt!5e0!3m2!1sen!2s!4v1533116958376" width="100%" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
</div>
<div class="panel panel">
	<div class="panel-heading">Đối Tác Của Chúng Tôi</div>
	<div class="panel-body">
		<a href="http://tiat.com.vn/index.php" target="_blank" > <img src="images/quangcao.jpg" style="width: 100%"> </a>	
	</div>
</div>
